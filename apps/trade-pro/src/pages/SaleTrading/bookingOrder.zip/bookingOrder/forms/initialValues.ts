export const detailInitialValues = {
  item: 'item1',
  weight: '',
  unitPrice: '',
  totalPrice: '',
};
