import { atom, useAtom } from 'jotai';

export const tableDataList = atom<any[]>([]);
